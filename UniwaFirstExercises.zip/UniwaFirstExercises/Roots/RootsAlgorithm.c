#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "StringCalculator.h"

int main(int argc, char const *argv[])
{
    




    return 0;
}
